﻿using System;

namespace Pokeman
{
	class ToyMachine
	{
		
		public static void Main (string [] args)
		{
			TransactionManager manager = new TransactionManager ();
			manager.StartTransaction();
		}
	}
}
