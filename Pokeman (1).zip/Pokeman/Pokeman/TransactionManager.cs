﻿using System;
namespace Pokeman
{
	public class TransactionManager
	{
		/// <summary>
		/// starts the user transaction .It handles taking order to calucating the total 
		/// cost of a transaction
		/// </summary>
		public void StartTransaction()
		{
			int userOption = 0;
			try
			{
				TransactionDetail transcationDetail = TakeOrder();

				//checking user has not selected any Pokemon
				if (transcationDetail.NoOfPikachus == 0 && transcationDetail.NoOfSquirtles == 0 && transcationDetail.NoOfCharmanders == 0)
				{
					Console.WriteLine("you have selected none of the Pokemons \n type 1 to start new transaction or  type 2 to exit");
					int.TryParse(Console.ReadLine(), out userOption);
					ValidateUserInput(userOption);
				}
				else if (transcationDetail.NoOfPikachus < 0 || transcationDetail.NoOfSquirtles < 0 || transcationDetail.NoOfCharmanders < 0)
				{
					Console.WriteLine("you have selected negative value \n type 1 to start new transaction or  type 2 to exit");
					int.TryParse(Console.ReadLine(), out userOption);
					ValidateUserInput(userOption);
				}
				else {
					transcationDetail.TotalCost = CalculateTotalCost(transcationDetail.NoOfPikachus, transcationDetail.NoOfSquirtles, transcationDetail.NoOfCharmanders);
					Console.WriteLine("Total cost is  : {0} ", transcationDetail.TotalCost);
				}
			}

			catch (Exception e)
			{
				Console.WriteLine("Please enter an invalid number " + e.Message);
				Console.WriteLine("Previous transactin transaction was canceled");
				Console.WriteLine("type 1 to start new transaction or type 2 to exit");
				int.TryParse(Console.ReadLine(), out userOption);
				ValidateUserInput(userOption);
			}

		}

		/// <summary>
		/// Validates the user input.If input has value 1 restarts the transaction
		/// other than it exits the application
		/// </summary>
		/// <param name="input">User Input</param>
		private void ValidateUserInput(int input)
		{
			switch (input)
			{
				case 1:
					StartTransaction();
					break;
				case 2:
					Console.WriteLine("Thank You Byeee");
					Environment.Exit(0);
					break;
				default:
					Console.WriteLine("you have enter an invalid number byeee");
					Environment.Exit(0);
					break;
							
			}
		}

		/// <summary>
		/// Takes the user input values and stores in object 
		/// </summary>
		/// <returns>TransactionDetail object containging no of each type  of Pokemon order .</returns>
		private TransactionDetail TakeOrder()
		{
			int pikachus;
			int squirtles;
			int charmanders;

			//retrieving values from user
			Console.WriteLine("please enter no of Pikachu's you want ");
			pikachus = int.Parse(Console.ReadLine());
			Console.WriteLine("please enter no of Squirtle's you want ");
			squirtles = int.Parse(Console.ReadLine());
			Console.WriteLine("please enter no of Charmander's you want ");
			charmanders= int.Parse(Console.ReadLine());


			//Assigning users values to model object
			var transactionDetail = new TransactionDetail();
			transactionDetail.NoOfPikachus = pikachus;
			transactionDetail.NoOfSquirtles = squirtles;
			transactionDetail.NoOfCharmanders = charmanders;

			return transactionDetail;


		}

		/// <summary>
		/// Calculates Total cost of Order
		/// </summary>
		/// <param name="pickachus">No of pickachus ordered</param>
		/// <param name="squirtles">No of squirtles ordered</param>
		/// <param name="charmanders">No of charmanders ordered</param> 
		private double CalculateTotalCost(int pickachus, int squirtles, int charmanders)
		{
			double cost = 0;
			int greatestNumber;

			//calculate highest number  of pokeman's of
			//particular type 
			if (pickachus >= squirtles && pickachus >= charmanders)
				greatestNumber = pickachus;
			else if (squirtles >= pickachus && squirtles >= charmanders)
				greatestNumber = squirtles;
			else
				greatestNumber = charmanders;

			//calculating the cost set wise
			//by taking maximum of one and minimum of zero
			//Pokemon per type in a set
			//dividing greatestNumber number sets
			//each set may one or none from each type of Pokemon
			for (int i = 0; i < greatestNumber; i++)
			{
				cost += CalucSetCost(pickachus > 0 ? 1 : 0, squirtles > 0 ? 1 : 0, charmanders > 0 ? 1 : 0);
				pickachus--;
				squirtles--;
				charmanders--;
			}
			return cost;
		}

		/// <summary>
		/// Calculates  cost of each set of Pokemons.Set may contain one or 
		/// none from each type of Pokemon
		/// </summary>
		/// <param name="pickachu">value 1 indicates present of that type Pokemon in the set.value
		/// 						value 0 indicates absent of that type Pokemon in the set</param>
		/// <param name="squirtle">value 1 indicates present of that type Pokemon in the set.value
		/// 						value 0 indicates absent of that type Pokemon in the set</param>
		/// <param name="charmander">value 1 indicates present of that type Pokemon in the set.value
		/// 						value 0 indicates absent of that type Pokemon in the set</param> 
		private double CalucSetCost(int pickachu, int squirtle, int charmander)
		{
			double cost;
			double disPercentage = getDiscountpercentage(pickachu + squirtle + charmander);
			cost = ((100 - disPercentage) / 100) * (pickachu * getPickachuCost() + squirtle * getSquirtleCost() + charmander * getCharmanderCost());
			return cost;
		}

		/// <summary>
		/// Returns discount percentage according to different type of Pokemon's in 
		/// a set 
		/// </summary>
		/// <returns >Discount Percentage</returns>
		private double getDiscountpercentage(int noofDifferetitem)
		{
			switch (noofDifferetitem)
			{
				case 2:
					return 10;
				case 3:
					return 20;
				default:
					return 0;
			}
		}

		/// <summary>
		/// Returns cost of a Pickachu 
		/// </summary>
		/// <returns >Price of Pickachu</returns>
		private double getPickachuCost()
		{
			return 6;
		}

		/// <summary>
		/// Returns cost of a Squirtle 
		/// </summary>
		/// <returns >Price of Squirtle</returns>
		private double getSquirtleCost()
		{
			return 5;
		}

		/// <summary>
		/// Returns cost of a Charmander 
		/// </summary>
		/// <returns >Price of Charmander</returns>
		private double getCharmanderCost()
		{
			return 5;
		}

	}
}

