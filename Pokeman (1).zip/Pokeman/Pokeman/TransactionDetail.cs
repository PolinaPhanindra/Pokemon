﻿using System;
namespace Pokeman
{
	public class TransactionDetail
	{

		int noOfPikachus;
		int noOfSquirtles;
		int noOfCharmanders;
		double totalCost;


		public TransactionDetail ()
		{
			noOfPikachus = 0;
			noOfSquirtles = 0;
			noOfCharmanders = 0;
			totalCost = 0;
		}

		/// <summary>
		/// Gets or Sets total number of Pikachu's Ordered
		/// </summary>
		/// <value>No Of Pickachu's Ordered.</value>
		public int NoOfPikachus {
			get {
				return noOfPikachus;
			}

			set {
				noOfPikachus = value;
			}
		}

		/// <summary>
		/// Gets or Sets total number of Squirtle's Ordered
		/// </summary>
		/// <value>No Of Squirtle's Ordered.</value>

		public int NoOfSquirtles {
			get {
				return noOfSquirtles;
			}

			set {
				noOfSquirtles = value;
			}
		}

		/// <summary>
		/// Gets or Sets total number of Charmander's Ordered
		/// </summary>
		/// <value>No Of Charmander's Ordered.</value>
		public int NoOfCharmanders {
			get {
				return noOfCharmanders;
			}

			set {
				noOfCharmanders = value;
			}
		}

		/// <summary>
		/// Gets or Sets total cost of the Order.
		/// </summary>
		/// <value>Total Cost.</value>
		public double TotalCost
		{
			get
			{
				return totalCost;
			}

			set
			{
				totalCost = value;
			}
		}
	}
}

